import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JFrame;

public class Item extends JFrame{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
		protected JLabel explain = new JLabel("(�`�N!�M�\�ݷf�t�D�\�A�B�@���D�\���I�@�M�\)");
		protected JLabel menusub = new JLabel("�I��");
		protected JLabel menudrinks = new JLabel("����");
	
		//����������
		protected JLabel food1 = new JLabel("�j���J");
		protected JLabel food2 = new JLabel("������");
		protected JLabel food3 = new JLabel("���ֳ�");
		protected JLabel food4 = new JLabel("����(�p)");
		protected JLabel food5 = new JLabel("����(��)");
		protected JLabel food6 = new JLabel("����(�j)");
		protected JLabel food7 = new JLabel("����");
		protected JLabel food8 = new JLabel("�i��(�p)");
		protected JLabel food9 = new JLabel("����(�p)");
		protected JLabel food10 = new JLabel("�ɦ̿@��");
		
		//�զX�M�\����
		protected JLabel normal = new JLabel("���q�M�\");
		protected JLabel normal1 = new JLabel("(���t ����(��)�B����(�p) �i����)");
		protected JLabel hashbrowns = new JLabel("����M�\");
		protected JLabel hashbrowns1 = new JLabel("(���t ����(�p)�B����B�i��(�p) �i����)");
		protected JLabel large = new JLabel("�Y�ܹ��M�\");
		protected JLabel large1 = new JLabel("(���t ����(�j)�B����(�p) �i����)");
		
		//����������
		public int a = 72;
		public int b = 44;
		public int c = 48;
		public int d = 33;
		public int e = 44;
		public int f = 55;
		public int g = 30;
		public int h = 28;
		public int i = 28;
		public int j = 40;
		public int o = 60;
		public int m = 70;
		public int n = 70;
		
		//��������L�̪������ܦ�����
		protected JLabel price1 = new JLabel(Integer.toString(a));
		protected JLabel price2 = new JLabel(Integer.toString(b));
		protected JLabel price3 = new JLabel(Integer.toString(c));
		protected JLabel price4 = new JLabel(Integer.toString(d));
		protected JLabel price5 = new JLabel(Integer.toString(e));
		protected JLabel price6 = new JLabel(Integer.toString(f));
		protected JLabel price7 = new JLabel(Integer.toString(g));
		protected JLabel price8 = new JLabel(Integer.toString(h));
		protected JLabel price9 = new JLabel(Integer.toString(i));
		protected JLabel price10 = new JLabel(Integer.toString(j));
		protected JLabel price11 = new JLabel(Integer.toString(o));
		protected JLabel price12 = new JLabel(Integer.toString(m));
		protected JLabel price13 = new JLabel(Integer.toString(n));
		
		//�ثe�ʪ����̪��ƶq
		protected int x =0;
		protected int y =0;
		protected int z =0;
		protected int v =0;
		protected int w =0;
		protected int u =0;
		protected int p =0;
		protected int q =0;
		protected int k =0;
		protected int s =0;
		protected int package1quan =0;
		protected int package2quan =0;
		protected int package3quan =0;
		
		public int getX() {return this.x;}
		
		//���ʪ����̪��ƶq�ܦ�����
		protected JLabel quantity1 = new JLabel(Integer.toString(x));
		protected JLabel quantity2 = new JLabel(Integer.toString(y));
		protected JLabel quantity3 = new JLabel(Integer.toString(z));
		protected JLabel quantity4 = new JLabel(Integer.toString(v));
		protected JLabel quantity5 = new JLabel(Integer.toString(w));
		protected JLabel quantity6 = new JLabel(Integer.toString(u));
		protected JLabel quantity7 = new JLabel(Integer.toString(p));
		protected JLabel quantity8 = new JLabel(Integer.toString(q));
		protected JLabel quantity9 = new JLabel(Integer.toString(k));
		protected JLabel quantity10 = new JLabel(Integer.toString(s));
		protected JLabel quantity11 = new JLabel(Integer.toString(package1quan));
		protected JLabel quantity12 = new JLabel(Integer.toString(package2quan));
		protected JLabel quantity13 = new JLabel(Integer.toString(package3quan));
		
		//�s�W���s
		protected JButton button1 = new JButton("+");
		protected JButton button2 = new JButton("-");
		protected JButton button3 = new JButton("+");
		protected JButton button4 = new JButton("-");
		protected JButton button5 = new JButton("+");
		protected JButton button6 = new JButton("-");
		protected JButton button7 = new JButton("+");
		protected JButton button8 = new JButton("-");
		protected JButton button9 = new JButton("+");
		protected JButton button10 = new JButton("-");
		protected JButton button11 = new JButton("+");
		protected JButton button12 = new JButton("-");
		protected JButton button13 = new JButton("+");
		protected JButton button14 = new JButton("-");
		protected JButton button15 = new JButton("+");
		protected JButton button16 = new JButton("-");
		protected JButton button17 = new JButton("+");
		protected JButton button18 = new JButton("-");
		protected JButton button19 = new JButton("+");
		protected JButton button20 = new JButton("-");
		protected JButton button21 = new JButton("+");
		protected JButton button22 = new JButton("-");
		protected JButton button23 = new JButton("+");
		protected JButton button24 = new JButton("-");
		protected JButton button25 = new JButton("+");
		protected JButton button26 = new JButton("-");
		protected JButton ok = new JButton("�T�{�ðe�X");
}